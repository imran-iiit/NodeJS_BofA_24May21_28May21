
import React from 'react'
import ReactDOM from 'react-dom'
import MAinApp from './components/MainApp'

ReactDOM.render(<MAinApp/>,
    document.getElementById('app')
    )