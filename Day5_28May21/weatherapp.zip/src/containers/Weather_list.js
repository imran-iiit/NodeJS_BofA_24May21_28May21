 
import React,{Component} from 'react'
export default class WeatherList extends Component {




    render() {
        return(
            <div>
                weatherList
            </div>
        )
    }




}